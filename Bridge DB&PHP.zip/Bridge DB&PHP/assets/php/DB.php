<?php

$DSN = 'mysql:host=localhost;dbname=record';
$ConnectingDB = new PDO($DSN,'root','');

?>